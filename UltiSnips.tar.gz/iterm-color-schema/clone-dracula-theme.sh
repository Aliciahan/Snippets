#!/bin/bash

cd ~/Projects/00-else/ &&\
  git clone https://github.com/dracula/iterm.git 
