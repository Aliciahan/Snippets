#!/bin/bash
cp ~/.vimrc ./vimrcWindows
