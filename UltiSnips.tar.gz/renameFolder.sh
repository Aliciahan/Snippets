#!/bin/bash

cd .. &&\
mv Snippets UltiSnips &&\
echo "[Done]"
