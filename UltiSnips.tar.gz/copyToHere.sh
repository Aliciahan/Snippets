#!/bin/bash

cp -f ~/.vimrc ./
