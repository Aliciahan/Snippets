aria2c --conf-path="/Users/xicunhan/bin/aria2.conf" -D
