#!/bin/bash
cp *.snippets ../bundle/vim-snippets/UltiSnips/ 

